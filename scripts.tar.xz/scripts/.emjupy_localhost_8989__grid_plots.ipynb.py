# %% [emjupy:43]
import numpy as np
import glob
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib as mpl
from MESAreader import get_src_col, get_model_initial_values, Rsun_cm
import matplotlib.colors as mcolors
from joblib import Parallel, delayed
from scipy.interpolate import interp1d
%load_ext autoreload


# %% [emjupy:44]
root = "../data/" # final / needed
hfiles = sorted(glob.glob(root+"*/LOGS/history.data"))
models = sorted(glob.glob(root+"*.*/"))
print(f"Number of successful models in the grid: {len(hfiles)}")

# %% [emjupy:45]
# bounds = np.linspace(30, 100, 71)+0.5   # for coloring by mass
bounds = np.linspace(0.5, 1, 11)-0.001  # for coloring by rotation
cmap = mpl.colormaps["viridis"].resampled(len(bounds) - 1)   # one color per interval
norm = mcolors.BoundaryNorm(boundaries=bounds, ncolors=cmap.N)

# %% [emjupy:46]


# test

# %% [emjupy:47]
# Composition profiles
fig = plt.figure()
gs = gridspec.GridSpec(150, 100)
ax = fig.add_subplot(gs[:, :])
models = sorted(glob.glob(root+"*.*rot*/"))

for m in models:
    pfile = m+"/LOGS/CHE_single_core_collapse.data"
    M, o = get_model_initial_values(m)
    c = cmap(norm(o))
    src, col = get_src_col(pfile)
    c12 = src[:, col.index("c12")]
    o16 = src[:, col.index("o16")]
    si28 = src[:, col.index("si28")]
    he4 = src[:, col.index("he4")]
    m = src[:, col.index("mass")]
    if M==40 and o==0.6:
        ax.plot(m, he4, c='C1', ls=':',lw=3, zorder=10)
        ax.plot(m, c12, c='C1', ls=':',lw=3, zorder=10)
        ax.plot(m, o16, c='C1', ls='--',lw=3, zorder=10)
        ax.plot(m, si28, c='C1', ls='-',lw=3, zorder=10)
        small_net = "../data/SMALL_NET/40_rot0.6_small_net/LOGS1/CHE_single_core_collapse.data"
        src, col = get_src_col(small_net)
        ax.plot(m, he4, c='k', ls=':',lw=1, alpha=1, zorder=10)
        ax.plot(m, c12, c='k', ls=':',lw=1, alpha=1, zorder=10)
        ax.plot(m, o16, c='k', ls='--',lw=1,alpha=1,  zorder=10)
        ax.plot(m, si28, c='k', ls='-',lw=1,alpha=1,  zorder=10)        
    else:
        ax.plot(m, he4, c=c, ls=':', lw=0.5, alpha=0.3, zorder=1)
        ax.plot(m, c12, c=c, ls=':', lw=0.5, alpha=0.3, zorder=1)
        ax.plot(m, o16, c=c, ls='--', lw=0.5, alpha=0.3, zorder=1)
        ax.plot(m, si28, c=c, ls='-', lw=0.5, alpha=0.3, zorder=1)

ax.set_yscale('log')
ax.set_ylim(1e-6, 1)

ax.set_xscale('log')
ax.set_xlim(xmin=5e-1,xmax=60)
ax.invert_xaxis()

ax.set_ylabel(r"Mass fraction $X_{i}$")
ax.set_xlabel(r"$m\ [M_{\odot}]$")

# %% [emjupy:48]
fig = plt.figure()
gs = gridspec.GridSpec(150, 100)
ax = fig.add_subplot(gs[:, :])

ax.invert_xaxis()
ax.set_xlabel(r"$\log_{10}(T_\mathrm{eff}/[K])$")
ax.set_ylabel(r"$\log_{10}(L/L_\odot)$")

models = sorted(glob.glob(root+"*.*rot*/"))
for m in models:
    # print(m)
    hfile = m+"/LOGS/history.data"
    M, o = get_model_initial_values(m)
    c = cmap(norm(o))
    # print(M, o)
    src, col = get_src_col(hfile)
    logT = src[:, col.index("log_Teff")]
    logL = src[:, col.index("log_L")]
    ax.plot(logT, logL, lw=0.5, alpha=0.3, c=c)
    if M==40 and o==0.6:
        ax.plot(logT, logL, lw=3, c='C1',zorder=10)

# for README
plt.savefig('../manuscript/figures/HRD_grid.png')

# %% [emjupy:50]
from multi_panel import my_mark_inset

fig = plt.figure()
gs = gridspec.GridSpec(150, 100)
ax = fig.add_subplot(gs[:, :])
# zx = ax.inset_axes([0.3, 0.76, 0.68, 0.2])  # for x=mass
zx = ax.inset_axes([0.13, 0.11, 0.68, 0.4])  # for x=logM


for mod in models:
    pfile = mod+"LOGS/CHE_single_core_collapse.data"
    src, col = get_src_col(pfile)
    M, o = get_model_initial_values(mod)
    if M != 40 or o != 0.6: continue
    c = cmap(norm(o))
    logrho = src[:, col.index("logRho")]
    m = src[:, col.index("mass")]
    ax.plot(m, logrho, c=c, alpha=0.3, lw=0.5)
    zx.plot(m, logrho, c=c, alpha=0.3, lw=0.5)
    if M==40 and o==0.6:
        ax.plot(m, logrho, lw=10, c='darkblue', zorder=9)
        ax.plot(m, logrho, lw=3, c='C1', zorder=10)
        zx.plot(m, logrho, lw=10, c='darkblue', zorder=9)
        zx.plot(m, logrho, lw=3, c='C1', zorder=9)

small_net = "../data/SMALL_NET/40_rot0.6_small_net/LOGS1/CHE_single_core_collapse.data"
src, col = get_src_col(small_net)
logrho = src[:, col.index("logRho")]
m = src[:, col.index("mass")]
ax.plot(m, logrho, lw=3, c='orchid', ls='-', zorder=10)
zx.plot(m, logrho, lw=3, c='orchid', ls='-',  zorder=10)


ax.set_ylim(-10, 10.5)
ax.set_xscale('log')
ax.set_xlim(5e-4, 50)
zx.set_xlim(5e-4, 5.5)
zx.set_ylim(2,10)
ax.set_xlabel(r"$m\ [M_{\odot}]$")
ax.set_ylabel(r"$\log_{10}(\rho/\mathrm{[g\ cm^{-3}}])$")
my_mark_inset(ax, zx, loc1a=2, loc1b=3, loc2a=1, loc2b=4)
ax.set_xticks([1e-3, 1e-1, 1e1], minor=True)
ax.set_xticklabels([], minor=True)
# For Readme
# plt.savefig('../manuscript/figures/rho_grid.png')
plt.savefig('/tmp/rho_grid_focus.png')

# %% [emjupy:52]
fig = plt.figure()
gs = gridspec.GridSpec(150, 100)
ax = fig.add_subplot(gs[:, :])

for mod in models:
    pfile = mod+"LOGS/CHE_single_core_collapse.data"
    src, col = get_src_col(pfile)
    logr = np.log10((10.**(src[:, col.index("logR")]))*Rsun_cm)
    r = 10.0**logr
    omega = src[:, col.index("omega")]
    j_specific = r*r*omega
    m = src[:, col.index("mass")]
    M, o = get_model_initial_values(mod)
    c = cmap(norm(o))
    ax.plot(m, j_specific, c=c, alpha=0.3, lw=0.5)
    if M==40 and o==0.6:
        ax.plot(m, j_specific, lw=3, c='C1', zorder=10)


ax.set_yscale('log')
ax.set_ylim(1e14, 1e19)
ax.set_xscale('log')
ax.set_xlim(1e-1, 50)
ax.set_yticks([1e15, 1e17, 1e19], minor=True)
ax.set_yticklabels([], minor=True)
ax.set_xlabel(r"$m\ [M_{\odot}]$")
ax.set_ylabel(r"$\log_{10}(j/\mathrm{[cm^{2}\ s^{-1}]})$")

plt.savefig('../manuscript/figures/j_grid.png')


# %% [emjupy:54]
fig = plt.figure(figsize=(8,16))
gs = gridspec.GridSpec(100, 100)
ax0 = fig.add_subplot(gs[:50, :])
ax1 = fig.add_subplot(gs[50:, :])

for mod in models:
    pfile = mod+"LOGS/CHE_single_core_collapse.data"
    src, col = get_src_col(pfile)
    m = src[:, col.index("mass")]
    Bphi = 10.0**(src[:, col.index("dynamo_log_B_phi")])
    Br = 10.0**(src[:, col.index("dynamo_log_B_r")])
    ax0.plot(m, Bphi, c='C0', alpha=0.3, lw=0.5)
    ax1.plot(m, Br, c='C0', alpha=0.3, lw=0.5)
    M, o = get_model_initial_values(mod)
    if M==40 and o==0.99:
        ax0.plot(m, Bphi, lw=3, c='C1', zorder=10)
        ax1.plot(m, Br, lw=3, c='C1', zorder=10)

# ax0.set_yscale('log')
# ax0.set_ylim(ymin=0, ymax0=14)
ax0.set_ylim(1e4, 1e13)
ax0.set_yscale('log')
ax0.set_xscale('log')
ax0.set_xlim(5e-4, 50)
ax0.set_xticks([1e-3, 1e-1, 1e1], minor=True)
ax0.set_xticklabels([], minor=True)
ax0.set_yticks([1e13, 1e11, 1e9, 1e7, 1e5], minor=True)
ax0.set_yticklabels([], minor=True)
ax1.set_ylim(1e4, 1e13)
ax1.set_yscale('log')
ax1.set_xscale('log')
ax1.set_xlim(5e-4, 50)
ax1.set_xticks([1e-3, 1e-1, 1e1], minor=True)
ax1.set_xticklabels([], minor=True)
ax1.set_yticks([1e13, 1e11, 1e9, 1e7, 1e5], minor=True)
ax1.set_yticklabels([], minor=True)
ax1.set_xlabel(r"$m\ [M_{\odot}]$")



ax1.set_xlabel(r"$m\ [M_{\odot}]$")
ax1.set_ylabel(r"$\log_{10}(B_{r}/\mathrm{[G]})$")
ax0.set_ylabel(r"$\log_{10}(B_{\varphi}/\mathrm{[G]})$")
# plt.savefig('../manuscript/figures/B_grid.png')


# %% [emjupy:56]
fig = plt.figure()
gs = gridspec.GridSpec(150, 100)
ax = fig.add_subplot(gs[:, :])

for mod in models:
    pfile = mod+"LOGS/CHE_single_core_collapse.data"
    src, col = get_src_col(pfile)
    m = src[:, col.index("mass")]
    ye = src[:, col.index('ye')]
    M, o = get_model_initial_values(mod)
    c = cmap(norm(o))        
    ax.plot(m, ye, c=c, alpha=0.3, lw=0.5)
    if M==40 and o==0.6:
        ax.plot(m, ye, lw=3, c='C1', zorder=10)
        # this model is available at https://zenodo.org/records/11375523
        # small_net = "../data/SMALL_NET/40_rot0.6_small_net/LOGS1/CHE_single_core_collapse.data"
        # src, col = get_src_col(small_net)
        # m = src[:, col.index("mass")]
        # ye = src[:, col.index('ye')]
        # ax.plot(m, ye, c='k', ls='-.', alpha=1, lw=1, zorder=10, label=r"small net")
        # ax.legend()

# ax.set_xscale('log')
ax.set_xlim(0, 4)
ax.set_ylim(0.44, 0.505)
ax.set_ylabel(r"$Y_e=\sum_j\,X_j Z_j / A_j$")
ax.set_xlabel(r"$m\ [M_{\odot}]$")
plt.savefig('../manuscript/figures/Ye_grid.png')

# %% [emjupy:58]
fig = plt.figure()
gs = gridspec.GridSpec(150, 100)
ax = fig.add_subplot(gs[:, :])

for mod in models:
    pfile = mod+"LOGS/CHE_single_core_collapse.data"
    src, col = get_src_col(pfile)
    s = src[:, col.index("entropy")]
    m = src[:, col.index("mass")]
    M, o = get_model_initial_values(mod)
    c = cmap(norm(o))
    ax.plot(m, s, c=c, alpha=0.3, lw=0.5)
    if M==40 and o==0.6:
        ax.plot(m, s, lw=3, c='C1', zorder=10)
    

ax.set_ylim(0, 15)
ax.set_xscale('log')
ax.set_xlim(5e-4, 50)
ax.set_xlabel(r"$m\ [M_{\odot}]$")
ax.set_ylabel(r"specific entropy $s\ [k_{B}N_{A}]$")
ax.set_xticks([1e-3, 1e-1, 1e1], minor=True)
ax.set_xticklabels([], minor=True)
ax.axhline(4, 0,1,lw=2, ls='--', c='r')
plt.savefig('../manuscript/figures/entropy_grid.png')

# %% [emjupy:60]
from multi_panel import my_mark_inset

fig = plt.figure(figsize=(15,15))
gs = gridspec.GridSpec(2, 2)
ax0 = fig.add_subplot(gs[0])
ax1 = fig.add_subplot(gs[1])
ax2 = fig.add_subplot(gs[2])
ax3 = fig.add_subplot(gs[3])
zx = ax2.inset_axes([0.13, 0.11, 0.68, 0.4])  # for x=logM
for mod in models:
        hfile = mod+"/LOGS/history.data"
        M, o = get_model_initial_values(mod)

        # HRD ---------------------------------------
        src, col = get_src_col(hfile)
        logT = src[:, col.index("log_Teff")]
        logL = src[:, col.index("log_L")]
        ax0.plot(logT, logL, lw=0.5, alpha=0.3, c='C0')
        if M==40 and o==0.6:
            ax0.plot(logT, logL, lw=3, c='C1',zorder=10, label=r"$40\,M_{\odot},\ \frac{\omega_{\rm ZAMS}}{\omega_{\rm crit}}=0.6$"+"\n large network")

        # density -----------------------------
        pfile = mod+"LOGS/CHE_single_core_collapse.data"
        src, col = get_src_col(pfile)
        logrho = src[:, col.index("logRho")]
        m = src[:, col.index("mass")]
        ax2.plot(m, logrho, c='C0', alpha=0.3, lw=0.5)
        zx.plot(m, logrho, c='C0', alpha=0.3, lw=0.5)
        if M==40 and o==0.6:
            ax2.plot(m, logrho, lw=3, c='C1', zorder=10)
            zx.plot(m, logrho, lw=3, c='C1', zorder=10)

        # AM profile --------------------------------------------------
        # logr = np.log10((10.**(src[:, col.index("logR")]))*Rsun_cm)
        # r = 10.0**logr
        # omega = src[:, col.index("omega")]
        # j_specific = r*r*omega
        # m = src[:, col.index("mass")]
        # ax3.plot(m, j_specific, c='C0', alpha=0.3, lw=0.5)
        # if M==40 and o==0.6:
        #     ax3.plot(m, j_specific, lw=3, c='C1', zorder=1)

        # Ye ----------------------------------------------------
        m = src[:, col.index("mass")]
        ye = src[:, col.index('ye')]
        ax1.plot(m, ye, c='C0', alpha=0.3, lw=0.5, zorder=1)
        if M==40 and o==0.6:
            ax1.plot(m, ye, lw=3, c='C1', zorder=10)
            ax1.axvline(1.75, 0,1,ls='--', lw=2, zorder=9, c='k')

            small_net = "../data/SMALL_NET/40_rot0.6_small_net/LOGS1/CHE_single_core_collapse.data"
            src, col = get_src_col(small_net)
            m = src[:, col.index("mass")]
            logrho = src[:, col.index("logRho")]
            ye = src[:, col.index('ye')]
            logr = src[:, col.index("logR")]
            r = 10.0**logr
            omega = src[:, col.index("omega")]
            j_specific = r*r*omega
            ax1.plot(m, ye, c='k', ls='-.', lw=0.5, zorder=10)
            ax2.plot(m, logrho, lw=0.5, c='k', ls='-.', zorder=10)
            zx.plot(m, logrho, lw=0.5, ls='-.', c='k', zorder=10)
            ax3.plot(m, j_specific, lw=0.5, c='k', ls='-.', zorder=10)
            hfile =  "../data/SMALL_NET/40_rot0.6_small_net/LOGS1/history.data"
            src, col = get_src_col(hfile)
            logT = src[:, col.index("log_Teff")]
            logL = src[:, col.index("log_L")]
            ax0.plot(logT, logL, lw=0.5, ls='-.', c='k',zorder=10, label=r"$40\,M_{\odot},\ \frac{\omega_{\rm ZAMS}}{\omega_{\rm crit}}=0.6$"+"\n small network")
            ax0.legend(fontsize=20, handletextpad=0.1, frameon=True)



ax0.invert_xaxis()
ax0.set_xlabel(r"$\log_{10}(T_\mathrm{eff}/[K])$")
ax0.set_ylabel(r"$\log_{10}(L/L_\odot)$")

# ax1.set_xscale('log')
ax1.set_xlim(0, 4)
ax1.set_ylim(0.44, 0.505)
ax1.set_ylabel(r"$Y_e=\sum_j\,X_j Z_j / A_j$")
ax1.set_xlabel(r"$m\ [M_{\odot}]$")

ax2.set_ylim(-10, 10.5)
ax2.set_xscale('log')
ax2.set_xlim(1e-4, 50)
zx.set_xlim(1e-4, 5.5)
zx.set_ylim(2,10)
ax2.set_xlabel(r"$m\ [M_{\odot}]$")
ax2.set_ylabel(r"$\log_{10}(\rho/\mathrm{[g\ cm^{-3}}])$")
my_mark_inset(ax2, zx, loc1a=2, loc1b=3, loc2a=1, loc2b=4)
ax2.set_xticks([1e-3, 1e-1, 1e1], minor=True)
ax2.set_xticklabels([], minor=True)

ax3.set_yscale('log')
ax3.set_ylim(1e11, 1e19)

ax3.set_xscale('log')
ax3.set_xlim(1e-4, 50)
ax3.set_xticks([1e-3, 1e-1, 1e1], minor=True)
ax3.set_xticklabels([], minor=True)
ax3.set_yticks([1e12, 1e14, 1e16, 1e18], minor=True)
ax3.set_yticklabels([], minor=True)
ax3.set_xlabel(r"$m\ [M_{\odot}]$")
# ax3.set_xlabel(r"m [$M_{\odot}$]")
ax3.set_ylabel(r"$\log_{10}(j/\mathrm{[cm^{2}\ s^{-1}]})$")

fig.align_ylabels()


# %% [emjupy:61]

fig = plt.figure()
gs = gridspec.GridSpec(2, 2)
ax = fig.add_subplot(gs[0])
small_net = "../data/SMALL_NET/40_rot0.6_small_net/LOGS1/CHE_single_core_collapse.data"
src, col = get_src_col(small_net)
m = src[:, col.index("mass")]
logrho = src[:, col.index("logRho")]
ye = src[:, col.index('ye')]
logr = src[:, col.index("logR")]
r = (10.0**logr)*Rsun_cm
omega = src[:, col.index("omega")]
j_specific = r*r*omega
ax.plot(m, j_specific)

# %% [emjupy:63]
from make_table_content import compute_profile_quantities

# %% [emjupy:64]
fig = plt.figure()  # figsize=(16, 10))
gs = gridspec.GridSpec(150, 110)
ax0 = fig.add_subplot(gs[:, :100])
# ax1 = fig.add_subplot(gs[:, 70:120])
cax = fig.add_subplot(gs[:, 105:])

n_colors = 9
vmin, vmax = 0.55, 1.0

base_cmap = plt.cm.viridis
bounds = np.linspace(vmin, vmax, n_colors + 1)
norm = mcolors.BoundaryNorm(bounds, base_cmap.N)

cmap_discrete = mcolors.ListedColormap(
    [base_cmap(norm(v)) for v in (bounds[:-1] + bounds[1:]) / 2]
)
for mod in models:
    pfile = mod+"LOGS/CHE_single_core_collapse.data"
    hfile = mod+"LOGS/history.data"
    src, col = get_src_col(hfile)
    Mfe = src[-1, col.index("fe_core_mass")]
    mfes.append(Mfe)
    M, o = get_model_initial_values(mod)
    mzams.append(M)
    xi, M4, mu4 = compute_profile_quantities(pfile, M_compact=1.75, s_thresh=4.0)
    p = ax0.scatter(M, xi, c=o, s=100, cmap=cmap_discrete,
                   norm=mcolors.Normalize(vmin, vmax), zorder=2)
    # ax1.scatter(M4*mu4, mu4, c=o, s=100, cmap=cmap_discrete,
    #                norm=mcolors.Normalize(vmin, vmax), zorder=2)


# Plot Ertl lines
# x = np.linspace(0, 1.6)

# ertl_params = [
#     (0.274, 0.047),
#     (0.225, 0.0495),
#     (0.283, 0.043),
#     (0.284, 0.0393),
#     (0.194, 0.058),
# ]

# yy = []
# for k1, k2 in ertl_params:
#     y = k1 * x + k2
#     ax1.plot(x, y, lw=3, ls='--', c='r')
#     yy.append(y)

# min_y = [1e99]   * len(x)
# max_y = [1e-99]  * len(x)
# for y in yy:
#     min_y = np.minimum(min_y, y)
#     max_y = np.maximum(max_y, y)

# ax1.fill_between(x, min_y, max_y, fc="r", alpha=0.5, zorder=0)
# ax1.set_ylim(0, 0.8)
# ax1.set_xlim(0, 1.6)
# ax1.fill_between(x, max_y, 0.8, fc="#808080", zorder=0, alpha=1)

    
plt.colorbar(p, cax=cax)

ax0.set_xlabel(r"$M_{\rm ZAMS} \ [M_{\odot}]$")
ax0.set_ylabel(r"Compactness $\xi_{1.75}$")
cax.set_ylabel(r"$\omega_{\rm ZAMS}/\omega_{\rm crit}$")

plt.savefig('../manuscript/figures/xi_M.png')

# %% [emjupy:65]
# Alternative plot, similar axes as Fig 1
fig = plt.figure()
gs = gridspec.GridSpec(150, 110)
ax = fig.add_subplot(gs[:, :])
omegas = np.linspace(0.5, 0.99, 11)
masses = np.linspace(30, 100, 36)

existing = set()
for mod in models:
    M, o = get_model_initial_values(mod)
    existing.add((round(M,2), round(o,2)))

for mod in models:
    M, o = get_model_initial_values(mod)
    if (round(M,2), round(o,2)) in existing:
        pfile = mod+"LOGS/CHE_single_core_collapse.data"
        xi, M4, mu4 = compute_profile_quantities(pfile, M_compact=1.75, s_thresh=4.0)
        print(xi)
        p = ax.scatter(M, o, marker='o', c=xi, s=100, linestyle='None', vmin=0.5, vmax=0.65)
    else:
        ax.plot(M, o, marker='x', color='red', markersize=8, linestyle='None',
                markeredgewidth=1.5)


plt.colorbar(p)
ax.set_xlabel(r'$M_{\rm ZAMS} \ [M_{\odot}]$')
ax.set_ylabel(r'$\omega_{\rm ZAMS}/\omega_{\rm crit}$')
plt.tight_layout()

    

# %% [emjupy:66]
## Ertl parameters
fig = plt.figure(figsize=(10., 10.))
gs = gridspec.GridSpec(100, 100)
gs.update(wspace=0, hspace=0)
ax = plt.subplot(gs[:, :])

# Plot Ertl lines
x = np.linspace(0, 1.6)

ertl_params = [
    (0.274, 0.047),
    (0.225, 0.0495),
    (0.283, 0.043),
    (0.284, 0.0393),
    (0.194, 0.058),
]

yy = []
for k1, k2 in ertl_params:
    y = k1 * x + k2
    ax.plot(x, y, lw=3, ls='--', c='r')
    yy.append(y)

min_y = [1e99]   * len(x)
max_y = [1e-99]  * len(x)
for y in yy:
    min_y = min_array(min_y, y)
    max_y = max_array(max_y, y)

ax.fill_between(x, min_y, max_y, fc="r", alpha=0.5, zorder=0)
ax.set_ylim(0, 0.8)
ax.set_xlim(0, 1.6)
ax.fill_between(x, max_y, 0.8, fc="#808080", zorder=0, alpha=0.5)

# Plot scatter points
for f in folders:
    if myFolderSort(f) < 190:
        src, col = getSrcCol(getFinalProfile(f))
        s = src[:, col.index("entropy")]
        m = src[:, col.index("mass")]
        r = src[:, col.index("radius")]

        i = np.argmin(np.absolute(s - 4.0))
        dm = 0.3
        j = np.argmin(np.absolute((m[i] + dm) - m))

        M4  = m[i]
        mu4 = (m[j] - m[i]) / ((r[j] - r[i]) * Rsun_cm / 1e8)  # Eq. 5 in Ertl+2016

        mhe, mco, mrem, color, pulses = get_Mhe_rem_behavior(f)
        if pulses != "PISN":
            ax.scatter(M4 * mu4, mu4, c=color, s=50, zorder=10)

# Legend
ax.plot(np.nan, np.nan, lw=3, ls='--', c="r", label=r"$\mathrm{NS/BH\ boundary}$")
ax.scatter(np.nan, np.nan, c="g", s=50, label=r"PPI+CC")
ax.scatter(np.nan, np.nan, c="b", s=50, label=r"CC")
ax.legend(loc="upper left", numpoints=1)

# Annotations
ax.text(0.35, 0.45, r"collapse \\ BH formation",  fontsize=30, va="center", ha="center", transform=ax.transData)
ax.text(1.2,  0.1,  r"explosion \\ NS formation", fontsize=30, va="center", ha="center", transform=ax.transData)

# Ticks
ax.tick_params(axis='both', which='major', width=2, direction="in", top="on", right="on", length=12, pad=10, labelsize=30)
ax.tick_params(axis='both', which='minor', width=2, direction="in", top="on", right="on", length=6,  pad=10)

# Rectangle
R = mpatch.Rectangle((0, 0), 0.5, 0.3, fc="None", ec="k", ls=":", lw=2)
ax.add_artist(R)

# Locators & labels
ax.xaxis.set_major_locator(MultipleLocator(0.2))
ax.xaxis.set_minor_locator(MultipleLocator(0.1))
ax.yaxis.set_major_locator(MultipleLocator(0.1))
ax.yaxis.set_minor_locator(MultipleLocator(0.05))
ax.set_xlabel(r"$M_4\mu_4$", fontsize=30)
ax.set_ylabel(r"$\mu_4$",    fontsize=30)

plt.tight_layout()


# %% [emjupy:68]
Mprev = -99
for mod in models:
    pfile = mod+"LOGS/CHE_single_core_collapse.data"
    hfile = mod+"LOGS/history.data"
    src, col = get_src_col(hfile)
    Mfe = src[-1, col.index("fe_core_mass")]
    he4 = src[-1, col.index("surface_he4")]
    c12 = src[-1, col.index("surface_c12")]
    o16 = src[-1, col.index("surface_o16")]
    xi, M4, mu4 = compute_profile_quantities(pfile, M_compact=1.75, s_thresh=4.0)
    M, o = get_model_initial_values(mod)
    if M != Mprev:
        print("\hline")
        Mprev = M
    print(f"{M:.2f} & {o:.2f} & {xi:.3f} & {Mfe:.2f} & {M4:.2f} & {mu4:.3f} & {he4:.2f} & {c12:.2f} & {o16:.2f}"+r"\\")


# %% [emjupy:70]
models_tried = 11*36
success = len(models)/models_tried
print(f"Success rate: {success:.2f}")

# %% [emjupy:71]
fig = plt.figure()
gs = gridspec.GridSpec(150, 110)
ax = fig.add_subplot(gs[:, :])
omegas = np.linspace(0.5, 0.99, 11)
masses = np.linspace(30, 100, 36)

# Build a set of (M, omega) pairs from existing models
existing = set()
for mod in models:
    M, o = get_model_initial_values(mod)
    existing.add((round(M,2), round(o,2)))

for M in masses:
    for o in omegas:
        if (round(M,2), round(o,2)) in existing:
            ax.plot(M, o, marker='$✓$', color='green', markersize=10, linestyle='None')
        else:
            ax.plot(M, o, marker='x', color='red', markersize=8, linestyle='None',
                    markeredgewidth=1.5)

ax.set_xlabel(r'$M_{\rm ZAMS} \ [M_{\odot}]$')
ax.set_ylabel(r'$\omega_{\rm ZAMS}/\omega_{\rm crit}$')
plt.tight_layout()
# plt.savefig('../manuscript/figures/overview_grid.pdf')

# %% [emjupy:73]
maxR = -1

for mod in models:
    src, col = get_src_col(mod+'LOGS/history.data')
    R = max(10.**(src[:, col.index("log_R")]))
    print(mod, f"{R:.2f}")
    
    if R>= maxR:
        maxR=R

print(f"{maxR:.2f}")
